# final-project-group-3
final-project-group-3 created by GitHub Classroom

This GitHub contains the statistical analysis project of Group 3 from BIOS 635 done in collaboration.

4/14/2021 - Xueyao added data folder, created and uploaded spine.rmd and spine.html, which now contains data exploration part.

4/19/2021 - Ally added some stencil code for random forest.

4/23/2021 - Xueyao added some stencil code for SVM.

4/26/2021 - Xueyao updated some stencil code for random forest tuning parameters function.
